package mundo;

public class Rubik {

    private Cubo rubik[][][];
    /*
    discoxSup
    discoxInf
    discoYDer
    discoYIzq
    discoZFro
    discoZPos
    */
    public Rubik() {
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 7; j++) {
                for (int k = 0; k < 10; k++) {
                    rubik[i][j][k]= new Cubo();
                }
            }
        }
        System.out.println(rubik);
    }

    public Cubo[][][] getRubik() {
        return rubik;
    }
    
    //metodos funcionales
    public void giroEjeX() {//movimiento del dado de forma horizontal

        
    }

    public void giroEjeY() {//movimiento del dado de forma vertical

    }

    public void giroEjeZ() {//movimiento del dado de forma transversal

    }

}
