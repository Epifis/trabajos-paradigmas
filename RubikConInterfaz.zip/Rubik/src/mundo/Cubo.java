package mundo;

import java.awt.Color;

public class Cubo {

    private Color fro, der, izq, sup, inf, pos;
    private Color temp;

    /*
    colores
    1.Blanco
    2.Azul
    3.Rojo
    4.Verde
    5.Amarillo
    6.Naranja
     */

    public Cubo() {
        this.fro = Color.WHITE;
        this.der = Color.BLUE;
        this.izq = Color.RED;
        this.sup = Color.GREEN;
        this.inf = Color.YELLOW;
        this.pos = Color.ORANGE;
        
    }
 //metodos get

    public Color getFro() {
        return fro;
    }

    public Color getDer() {
        return der;
    }

    public Color getIzq() {
        return izq;
    }

    public Color getSup() {
        return sup;
    }

    public Color getInf() {
        return inf;
    }

    public Color getPos() {
        return pos;
    }

    public Color getTemp() {
        return temp;
    }
   

    //metodos funcionales
    public void giroEjeX() {//movimiento del dado de forma horizontal
        temp = fro;
        fro = izq;
        izq = pos;
        pos = der;
        der = temp;
    }
    
    public void giroEjeY() {//movimiento del dado de forma vertical
        temp = fro;
        fro = sup;
        sup = pos;
        pos = inf;
        inf = temp;
    }

    public void giroEjeZ() {//movimiento del dado de forma transversal
        temp = sup;
        sup = izq ;
        izq = inf;
        inf = der;
        der = temp;
    }

}
