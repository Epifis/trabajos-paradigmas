package interfaz;

import mundo.Rubik;

public class InterfazApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Rubik cubo1 = new Rubik();
        
    }
    
}
