package controlador;

import interfaz.PnlTablero;
import mundo.Logica;

public class Controlador {
    private PnlTablero pnlTablero;
    private Logica logica;

    public Controlador(PnlTablero pnlTablero) {
        this.pnlTablero = pnlTablero;
        this.logica = new Logica();
    }

    public PnlTablero getPnlTablero() {
        return pnlTablero;
    }

    public Logica getLogica() {
        return logica;
    }
    
    
}
