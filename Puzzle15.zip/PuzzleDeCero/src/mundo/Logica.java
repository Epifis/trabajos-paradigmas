package mundo;

import java.util.Random;

public class Logica {

    private int[][] tablero;
    private int fila16;
    private int columna16;
    private Random random;
    private int numeroMovs;

    public Logica() {
        random = new Random();
        this.tablero = new int[4][4];
        this.numeroMovs = 0;
        int contador = 1;
        for (int fila = 0; fila < 4; fila++) {
            for (int columna = 0; columna < 4; columna++) {
                tablero[fila][columna] = contador++;
            }
        }
        System.out.println("Tablero inicial:");
        for (int fila = 0; fila < 4; fila++) {
            for (int columna = 0; columna < 4; columna++) {
                System.out.print(tablero[fila][columna] + "\t");
            }
            System.out.println();
        }
    }

    public int getTablero(int i, int j) {
        return tablero[i][j];
    }

    public void buscarA16() {
        for (int fila = 0; fila < tablero.length; fila++) {
            for (int columna = 0; columna < tablero[fila].length; columna++) {
                if (tablero[fila][columna] == 16) {
                    fila16 = fila;
                    columna16 = columna;
                    return; // Salir del método después de encontrar la ficha 16
                }
            }
        }
        // Si no se encontró la ficha 16
        fila16 = -1;
        columna16 = -1;
    }

    public void intercambiarConVecino(int filaIngresada, int columnaIngresada) {
        buscarA16();

        // Verifica si la posición ingresada es un vecino de la posición de 16
        if (fila16 != -1 && columna16 != -1 && esVecino(fila16, columna16, filaIngresada, columnaIngresada)) {
            int temp = tablero[fila16][columna16];
            tablero[fila16][columna16] = tablero[filaIngresada][columnaIngresada];
            tablero[filaIngresada][columnaIngresada] = temp;
        } else if (fila16 != -1 && columna16 != -1 && estaEnLinea(fila16, columna16, filaIngresada, columnaIngresada)) {
            // Determinar la dirección del movimiento de la ficha 16
            int movimientoFila = filaIngresada - fila16;
            int movimientoColumna = columnaIngresada - columna16;

            // Mover fichas adyacentes según la dirección del movimiento de la ficha 16
            if (movimientoFila != 0) {
                // Mover fichas en la misma columna
                int inicioFila = (movimientoFila > 0) ? fila16 : filaIngresada;
                int finFila = (movimientoFila > 0) ? filaIngresada : fila16;
                for (int fila = inicioFila; fila < finFila; fila++) {
                    tablero[fila][columna16] = tablero[fila + movimientoFila][columna16];
                }
                tablero[fila16][columna16] = 16; // Mover ficha 16 a la posición seleccionada
            } else if (movimientoColumna != 0) {
                // Mover fichas en la misma fila
                int inicioColumna = (movimientoColumna > 0) ? columna16 : columnaIngresada;
                int finColumna = (movimientoColumna > 0) ? columnaIngresada : columna16;
                for (int col = inicioColumna; col < finColumna; col++) {
                    tablero[fila16][col] = tablero[fila16][col + movimientoColumna];
                }
                tablero[fila16][columna16] = 16; // Mover ficha 16 a la posición seleccionada
            }
        } else {
            System.out.println("La posición ingresada no es un vecino de 16 o 16 no está en la matriz.");
        }
    }

    public boolean estaEnLinea(int fila16, int columna16, int filaIngresada, int columnaIngresada) {
        // Verifica si la posición ingresada está en la misma fila o columna que la posición de la ficha 16
        return (fila16 == filaIngresada && columna16 == columnaIngresada) // Si están en la misma posición
                || (fila16 == filaIngresada) // Si están en la misma fila
                || (columna16 == columnaIngresada);  // Si están en la misma columna
    }

    public boolean esVecino(int fila16, int columna16, int filaIngresada, int columnaIngresada) {
        // Verifica si la posición ingresada está a una distancia de una unidad de la posición de 16
        return (Math.abs(fila16 - filaIngresada) == 1 && columna16 == columnaIngresada)
                || (Math.abs(columna16 - columnaIngresada) == 1 && fila16 == filaIngresada);
    }

    public void mover16Aleatoriamente(int numeroDesorden) {
        while (numeroDesorden > 1) {
            for (int fila = 0; fila < tablero.length; fila++) {
                for (int columna = 0; columna < tablero[fila].length; columna++) {
                    buscarA16();
                }
            }

            // Direcciones posibles: arriba, abajo, izquierda, derecha
            int[] filasMovimiento = {-1, 1, 0, 0};
            int[] columnasMovimiento = {0, 0, -1, 1};

            // Escoge una dirección aleatoria
            int indiceMovimiento = random.nextInt(4);

            // Calcula la nueva posición potencial
            int nuevaFila = fila16 + filasMovimiento[indiceMovimiento];
            int nuevaColumna = columna16 + columnasMovimiento[indiceMovimiento];

            // Verifica si la nueva posición es válida (es decir, si es un vecino válido)
            if (nuevaFila >= 0 && nuevaFila < tablero.length && nuevaColumna >= 0 && nuevaColumna < tablero[0].length) {
                // Intercambia los valores de las posiciones
                int temp = tablero[fila16][columna16];
                tablero[fila16][columna16] = tablero[nuevaFila][nuevaColumna];
                tablero[nuevaFila][nuevaColumna] = temp;
            }
            numeroDesorden -= 1;
        }
    }

    public int numeroMovimientos(int numeroMovs) {
        this.numeroMovs += 1;
        return this.numeroMovs;
    }

}
