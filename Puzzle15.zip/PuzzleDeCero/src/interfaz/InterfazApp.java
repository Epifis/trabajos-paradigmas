package interfaz;

import controlador.Controlador;

public class InterfazApp {

    private PnlTablero pnlTablero;
    private Controlador ctrl;
    
    public InterfazApp() {
        this.ctrl = new Controlador(pnlTablero);
        this.pnlTablero = new PnlTablero(ctrl);
        pnlTablero.setVisible(true);
    }
    
    public static void main(String[] args) {
        InterfazApp interfaz = new InterfazApp();
    }
}
